MARINE KING 0.2alpha

Run from the terminal:

`./Mark3`

Copyright 2021 Lukasz Wrona. All rights reserved.
