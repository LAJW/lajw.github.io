﻿Jeżeli gra się nie włącza (brak MSVCP120.DLL) - trzeba zainstalować redistributable (vcredist_x64 albo vcredist_x86).

Klawiatura:
W-S-A-D - góra/dół/lewo/prawo - sterowanie statkiem
Mysz - celowanie
LPM - strzelanie

Pad Xbox360:
Lewy joystick - sterowanie statkiem
Prawy joystick - celowanie i strzelanie

Czity:
Num+ - zwiększenie poziomu broni.
Num- - zmniejszenie poziomu broni.
Pause/break - pauza.
Enter - maksymalizacja/normalizacja okna (może nie działać)